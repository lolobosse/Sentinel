ministocks
==========

Any new features will be targeted at api-level 10 (Android 2.3.3)
